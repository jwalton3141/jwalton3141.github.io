#! /bin/bash

if [ ! -d "intelMKL" ]
then
    virtualenv -p python3 intelMKL
    source intelMKL/bin/activate
    pip install intel-numpy intel-scipy
    pip install pandas
fi

if [ ! -d "openBLAS" ]
then
    virtualenv -p python3 openBLAS
    source openBLAS/bin/activate
    pip install numpy scipy
    pip install pandas
fi

[ -d "output" ] || mkdir output

source intelMKL/bin/activate
echo "Benchmarking Intel's MKL performance..."
./scripts/run_bench.py intelMKL
echo Done

source openBLAS/bin/activate
echo Benchmarking openBLAS performance...
./scripts/run_bench.py openBLAS
echo Done

deactivate
echo Plotting results of benchmarking...
./scripts/summarise_output.py
echo Done
