#! /usr/bin/env python3

"""Graph tests."""

import os.path as path
import pandas as pd
import matplotlib.pyplot as plt

plt.style.use('seaborn')


def plot_all():
    """Plot speedup or lack thereof."""
    for test_type in ["np_linalg", "np_rand", "np_fft", "scipy_stats"]:
        get_type = [test.startswith(test_type) for test in intel.test]
        plot_group(intel.loc[get_type], blas.loc[get_type], test_type)


def plot_group(intel_group, blas_group, test_type):
    fig, ax = plt.subplots(1, 1)
    ax.bar(intel_group.index, blas_group.time / intel_group.time)

    labels = [string.replace("_", ".") for string in intel_group.test]

    ax.set_xticklabels(labels)
    ax.set_xticks(intel_group.index)

    ax.set_xlabel("Function")
    ax.set_ylabel("Speed up factor")

    fig.tight_layout()
    save_path = path.join("output", "{}.png".format(test_type))
    fig.savefig(save_path, format="png", bbox_inches='tight')


def load_data():
    """Load timings."""
    intel = pd.read_csv("output/intelMKL.csv")
    blas = pd.read_csv("output/openBLAS.csv")
    return intel, blas


if __name__ == "__main__":
    intel, blas = load_data()
    plot_all()
